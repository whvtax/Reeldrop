# ReelDrop — Video Downloader

> **Download Instagram Reels, Stories, TikToks and TikTok Stories — no watermarks, no sign-up.**

![ReelDrop UI](https://img.shields.io/badge/ReelDrop-Video%20Downloader-ff3c6f?style=for-the-badge&logo=instagram)
![Next.js](https://img.shields.io/badge/Next.js-14-black?style=for-the-badge&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=for-the-badge&logo=typescript)

---

## ✨ Features

- 📸 **Instagram** — Reels & feed videos
- 🌸 **Instagram Stories** — before they disappear
- 🎵 **TikTok** — watermark-free downloads
- ✨ **TikTok Stories** — save them too
- ⚡ Powered by the open-source [Cobalt API](https://cobalt.tools)
- 🎨 Dark mode UI — works great on mobile
- 📋 One-tap clipboard paste
- 🔁 Auto-fallback to manual download services

---

## 🗂 Project Structure

```
reeldrop/
├── app/
│   ├── layout.tsx        ← Root layout + metadata
│   ├── page.tsx          ← Main React component
│   ├── page.module.css   ← Scoped styles
│   └── globals.css       ← Global CSS variables + resets
├── lib/
│   └── cobalt.ts         ← Cobalt API logic + platform detection
├── public/               ← Static assets (favicon etc.)
├── next.config.js
├── package.json
├── tsconfig.json
├── vercel.json
└── .gitignore
```

---

## 🚀 Deploy to Vercel via GitHub

1. Push this folder to a new GitHub repository
2. Go to [vercel.com](https://vercel.com) → **New Project**
3. Import your GitHub repo
4. Vercel auto-detects Next.js — just click **Deploy**
5. Done! Your site is live 🎉

---

## 💻 Run Locally

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 🔧 API

Uses the **[Cobalt](https://cobalt.tools)** public API — free, open-source, no key required.

Multiple public Cobalt instances are tried in sequence for reliability:
1. `api.cobalt.tools`
2. `cobalt.api.timefracture.org`
3. `co.wuk.sh`

If all fail, fallback links to SnapInsta, SssTik, and Cobalt.tools are shown.

---

## ⚠️ Disclaimer

Personal use only. Always respect platform Terms of Service.

---

*Made with 💝*
