"use client";

import { useState, useRef } from "react";
import styles from "./page.module.css";
import { detectPlatform, fetchViaCobalt } from "../lib/cobalt";

export default function Home() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null); // { type: "info"|"error"|"success", message: string }
  const [result, setResult] = useState(null);
  const [platform, setPlatform] = useState(null);
  const [downloadState, setDownloadState] = useState("idle"); // idle | downloading | done | fallback
  const inputRef = useRef(null);

  async function pasteFromClipboard() {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
    } catch {
      inputRef.current?.focus();
    }
  }

  async function autoDownloadBest(options) {
    const best = options[0];
    setDownloadState("downloading");
    try {
      const resp = await fetch(best.url);
      if (!resp.ok) throw new Error("fetch failed");
      const blob = await resp.blob();
      const burl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = burl;
      a.download = best.filename || "video.mp4";
      a.click();
      setTimeout(() => URL.revokeObjectURL(burl), 15000);
      setDownloadState("done");
      setStatus({ type: "success", message: "✅ Download started!" });
    } catch {
      window.open(best.url, "_blank");
      setDownloadState("fallback");
      setStatus({ type: "info", message: "🔗 Opened in browser — tap & hold → Save Video" });
    }
  }

  async function handleFetch() {
    const trimmed = url.trim();
    setResult(null);
    setStatus(null);
    setDownloadState("idle");

    if (!trimmed) {
      setStatus({ type: "error", message: "⚠️ Please paste a video URL first." });
      return;
    }

    const detected = detectPlatform(trimmed);
    if (!detected) {
      setStatus({ type: "error", message: "❌ Supported: Instagram & TikTok only." });
      return;
    }

    setPlatform(detected);
    setLoading(true);
    setStatus({ type: "info", message: `Contacting ${detected.icon} ${detected.name}…` });

    try {
      const res = await fetchViaCobalt(trimmed, detected);
      setResult(res);
      setStatus({ type: "info", message: "Fetching best quality…" });
      await autoDownloadBest(res.options);
    } catch (err) {
      setStatus({
        type: "error",
        message: `❌ Could not fetch. Try the fallback links below. (${err.message})`,
      });
      setResult({ title: "Manual download", options: [] });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={styles.page}>
      <div className={`${styles.blob} ${styles.blob1}`} />
      <div className={`${styles.blob} ${styles.blob2}`} />

      <div className={styles.container}>
        {/* Header */}
        <header className={styles.header}>
          <div className={styles.logo}>
            <div className={styles.logoIcon}>⬇️</div>
            <span className={styles.logoText}>ReelDrop</span>
          </div>
          <p className={styles.tagline}>// Persistence beats talent //</p>
          <div className={styles.platforms}>
            {[
              { icon: "📸", label: "Instagram" },
              { icon: "🌸", label: "Instagram Stories" },
              { icon: "🎵", label: "TikTok" },
              { icon: "✨", label: "TikTok Stories" },
            ].map((p) => (
              <div key={p.label} className={styles.platformBadge}>
                <span>{p.icon}</span> {p.label}
              </div>
            ))}
          </div>
        </header>

        {/* Main Card */}
        <div className={styles.card}>
          <label className={styles.inputLabel}>Paste video URL</label>
          <div className={styles.inputRow}>
            <input
              ref={inputRef}
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleFetch()}
              className={styles.urlInput}
              placeholder="https://www.instagram.com/reel/..."
              autoComplete="off"
              spellCheck={false}
            />
            <button className={styles.pasteBtn} onClick={pasteFromClipboard}>
              📋 Paste
            </button>
          </div>

          <button className={styles.fetchBtn} onClick={handleFetch} disabled={loading}>
            {loading ? (
              <><span className={styles.spinner} /> Fetching…</>
            ) : (
              <>⬇ Get Download Link</>
            )}
          </button>

          {status && (
            <div className={`${styles.statusMsg} ${
              status.type === "error" ? styles.statusError :
              status.type === "success" ? styles.statusSuccess :
              styles.statusInfo
            }`}>
              {status.type === "info" && loading && <span className={styles.spinner} />}
              <span>{status.message}</span>
            </div>
          )}

          {result && (
            <div className={styles.resultCard}>
              <div className={styles.resultHeader}>
                <div className={styles.thumbPlaceholder}>🎬</div>
                <div className={styles.resultMeta}>
                  <div className={styles.resultTitle}>{result.title}</div>
                  <div className={styles.resultPlatform}>
                    <span className={styles.dot} />
                    {platform?.icon} {platform?.name}
                  </div>
                </div>
              </div>

              <div className={styles.downloadOptions}>
                {downloadState === "downloading" && (
                  <div className={styles.dlProgress}>
                    <span className={styles.spinner} />
                    <span>Downloading best quality…</span>
                  </div>
                )}
                {downloadState === "done" && (
                  <div className={styles.dlProgress} style={{ color: "var(--success)" }}>
                    ✅ Saved to Downloads!
                  </div>
                )}
                {downloadState === "fallback" && (
                  <div className={styles.dlProgress} style={{ color: "var(--warning)" }}>
                    🔗 Opened in browser — tap &amp; hold → Save Video
                  </div>
                )}
                {result.options.length === 0 && (
                  <>
                    <div className={styles.optionLabel}>Manual fallback services</div>
                    {[
                      { label: "SnapInsta", href: `https://snapinsta.app/?url=${encodeURIComponent(url)}` },
                      { label: "SssTik", href: `https://ssstik.io/?url=${encodeURIComponent(url)}` },
                      { label: "Cobalt.tools", href: `https://cobalt.tools/?u=${encodeURIComponent(url)}` },
                    ].map((link) => (
                      <a key={link.label} href={link.href} target="_blank" rel="noreferrer" className={styles.dlBtn}>
                        <div className={styles.quality}><span>🌐</span> Open in {link.label}</div>
                        <span className={styles.dlIcon}>↗</span>
                      </a>
                    ))}
                  </>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Notice */}
        <div className={styles.notice}>
          <strong>I made this just for you my love 💝</strong>
        </div>

        {/* How it works */}
        <div className={styles.how}>
          <div className={styles.howTitle}>— How It Works —</div>
          <div className={styles.steps}>
            {[
              { num: "01", text: "Copy the video link from Instagram or TikTok" },
              { num: "02", text: "Paste it here and click Get Download Link" },
              { num: "03", text: 'Tap download → tap share icon → "Save Video"' },
            ].map((s) => (
              <div key={s.num} className={styles.step}>
                <div className={styles.stepNum}>{s.num}</div>
                <div className={styles.stepText}>{s.text}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <footer className={styles.footer}>
        ReelDrop — personal use only · respects platform ToS
      </footer>
    </div>
  );
}
