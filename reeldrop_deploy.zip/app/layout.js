import "./globals.css";

export const metadata = {
  title: "ReelDrop — Video Downloader",
  description:
    "Download Instagram Reels, Stories, TikToks and TikTok Stories — no watermarks, no sign-up.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
